# A PyTorch implementation of a EfficientDet Object Detector

Forked and modified from https://github.com/rwightman/efficientdet-pytorch, many thanks!
