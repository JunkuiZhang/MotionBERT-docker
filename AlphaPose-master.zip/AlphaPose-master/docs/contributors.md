AlphaPose - Authors and Contributors
====================================



### Authors
AlphaPose is authored by [Hao-Shu Fang\*](https://fang-haoshu.github.io/), [Jiefeng Li\*](https://jeff-leaf.site/), Hongyang Tang, Chao Xu, Haoyi Zhu, [Yuliang Xiu](http://xiuyuliang.cn/), Yong-Lu Li, and [Cewu Lu](www.mvig.org). Cewu Lu is corresponding author.



### Contributors
We would also like to thank the following people who have highly contributed to AlphaPose:

[Hongyang Tang](): AlphaPose Tracking module developer

[Chao Xu](): AlphaPose pytorch 0.3.0 version contributor

[Haoyi Zhu](): AlphaPose whole-body keypoints developer

[Chenxi Wang](): AlphaPose mxnet version main developer

[Chongwei Liu](): AlphaPose c++ version developer

[Ruiheng Chang](): AlphaPose master version(old) detection module
