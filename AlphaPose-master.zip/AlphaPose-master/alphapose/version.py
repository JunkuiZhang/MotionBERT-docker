# GENERATED VERSION FILE
# TIME: Thu Jul 21 17:10:51 2022

__version__ = '0.6.0+29ace8c'
short_version = '0.6.0'
